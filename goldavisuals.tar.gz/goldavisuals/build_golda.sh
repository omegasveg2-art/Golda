#!/bin/sh
# needs: JDK, ANDROID_HOME with build-tools + a platform. out: GoldaVisuals.apk
set -e
BT=$(ls -d "$ANDROID_HOME"/build-tools/* | sort -V | tail -1)
AJ=$(ls -d "$ANDROID_HOME"/platforms/android-* | sort -V | tail -1)/android.jar
D=build_golda
rm -rf $D && mkdir -p $D/classes
"$BT/aapt2" link -o $D/base.apk -I "$AJ" --manifest AndroidManifest.xml --min-sdk-version 26 --target-sdk-version 33 --version-code 1 --version-name 1
javac -encoding UTF-8 -source 8 -target 8 -Xlint:-options -cp "$AJ" -d $D/classes $(find java -name '*.java')
"$BT/d8" --release --min-api 26 --lib "$AJ" --output $D $(find $D/classes -name '*.class')
(cd $D && zip -q base.apk classes.dex)
"$BT/zipalign" -f -p 4 $D/base.apk $D/aligned.apk
keytool -genkeypair -keystore $D/dbg.jks -storepass android -keypass android -alias k -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=golda" >/dev/null 2>&1
"$BT/apksigner" sign --ks $D/dbg.jks --ks-pass pass:android --key-pass pass:android --out GoldaVisuals.apk $D/aligned.apk
echo "ok -> GoldaVisuals.apk"
