package golda;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

/** full-screen transparent canvas running the enabled effects. Draw loop only runs while at least one effect is on. */
class FxView extends View {
    final Effect[] fx = { new AuroraEffect(), new StarsEffect(), new CometEffect(), new SnowEffect(), new PetalsEffect(), new FirefliesEffect() };
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private long last;

    FxView(Context c) { super(c); setWillNotDraw(false); }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        float d = getResources().getDisplayMetrics().density;
        for (Effect e : fx) e.resize(w, h, d);
    }

    @Override protected void onDraw(Canvas c) {
        long now = System.nanoTime();
        float dt = last == 0 ? 0.016f : Math.min(0.05f, (now - last) / 1e9f);
        last = now;
        float ga = Prefs.i("global.alpha") / 100f;
        boolean any = false;
        for (Effect e : fx) if (e.on()) { e.update(dt); e.draw(c, p, ga); any = true; }
        if (any) postInvalidateOnAnimation(); else last = 0;
    }
}
