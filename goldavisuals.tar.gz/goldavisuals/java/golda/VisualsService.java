package golda;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Overlay host: (1) click-through effects layer over the game, (2) draggable gold bubble, (3) settings menu. Visuals only. */
public class VisualsService extends Service {
    private WindowManager wm;
    private FxView fx;
    private View bubble, menu;
    private WindowManager.LayoutParams bubLp, menuLp;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent i, int f, int id) {
        startForeground(1, notif());
        if (fx == null) setup();
        return START_STICKY;
    }

    private Notification notif() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel("golda", "GoldaVisuals", NotificationManager.IMPORTANCE_LOW));
        return new Notification.Builder(this, "golda").setContentTitle("GoldaVisuals").setContentText("эффекты запущены")
                .setSmallIcon(android.R.drawable.btn_star_big_on).build();
    }

    private WindowManager.LayoutParams lp(int w, int h, int flags) {
        return new WindowManager.LayoutParams(w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT);
    }

    private void setup() {
        Prefs.init(this);
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);

        // effects layer: never takes touches, game stays fully playable
        fx = new FxView(this);
        WindowManager.LayoutParams fl = lp(-1, -1, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED);
        fl.gravity = Gravity.TOP | Gravity.START;
        wm.addView(fx, fl);
        Prefs.listener = () -> { if (fx != null) fx.invalidate(); };
        fx.invalidate();

        // bubble
        final int sz = Ui.dp(this, 46);
        bubble = new View(this) {
            final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            @Override protected void onDraw(Canvas c) {
                float r = getWidth() / 2f;
                p.setColor(0x44E6B450); c.drawCircle(r, r, r, p);
                p.setColor(0xFF15151D); c.drawCircle(r, r, r * 0.82f, p);
                p.setColor(Ui.GOLD); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(r * 0.1f); c.drawCircle(r, r, r * 0.82f, p);
                p.setStyle(Paint.Style.FILL); p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(r * 1.05f);
                c.drawText("G", r, r + r * 0.37f, p);
            }
        };
        bubLp = lp(sz, sz, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        bubLp.gravity = Gravity.TOP | Gravity.START; bubLp.x = Ui.dp(this, 10); bubLp.y = Ui.dp(this, 90);
        bubble.setOnTouchListener(new View.OnTouchListener() {
            float dx, dy; int sx, sy; boolean drag;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN: dx = e.getRawX(); dy = e.getRawY(); sx = bubLp.x; sy = bubLp.y; drag = false; return true;
                    case MotionEvent.ACTION_MOVE:
                        if (Math.abs(e.getRawX() - dx) + Math.abs(e.getRawY() - dy) > Ui.dp(VisualsService.this, 8)) drag = true;
                        if (drag) { bubLp.x = sx + (int) (e.getRawX() - dx); bubLp.y = sy + (int) (e.getRawY() - dy); wm.updateViewLayout(bubble, bubLp); }
                        return true;
                    case MotionEvent.ACTION_UP: if (!drag) toggleMenu(); return true;
                    default: return true;
                }
            }
        });
        wm.addView(bubble, bubLp);
    }

    private void toggleMenu() {
        if (menu != null) { try { wm.removeView(menu); } catch (Exception ignored) { } menu = null; return; }
        menu = buildMenu();
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int w, h;
        if (dm.widthPixels > dm.heightPixels) { w = Math.min(Ui.dp(this, 520), (int) (dm.widthPixels * 0.62f)); h = Math.min(Ui.dp(this, 360), (int) (dm.heightPixels * 0.88f)); }
        else { w = (int) (dm.widthPixels * 0.94f); h = (int) (dm.heightPixels * 0.62f); }
        menuLp = lp(w, h, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE);
        menuLp.gravity = Gravity.TOP | Gravity.START; menuLp.x = (dm.widthPixels - w) / 2; menuLp.y = (dm.heightPixels - h) / 2;
        wm.addView(menu, menuLp);
    }

    private View buildMenu() {
        final int p8 = Ui.dp(this, 8), p12 = Ui.dp(this, 12);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(Ui.round(Ui.BG, Ui.dp(this, 18), 0x66E6B450, Ui.dp(this, 1)));

        // header = drag handle
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL); head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(p12 + p8, p12, p12, p8);
        LinearLayout titles = new LinearLayout(this); titles.setOrientation(LinearLayout.VERTICAL);
        TextView t = new TextView(this); t.setText("GoldaVisuals"); t.setTextColor(Ui.GOLD); t.setTextSize(18); t.setTypeface(Typeface.DEFAULT_BOLD);
        TextView st = new TextView(this); st.setText("только визуальные эффекты · тащи за шапку"); st.setTextColor(Ui.DIM); st.setTextSize(11);
        titles.addView(t); titles.addView(st);
        head.addView(titles, new LinearLayout.LayoutParams(0, -2, 1));
        TextView x = new TextView(this); x.setText("✕"); x.setTextColor(Ui.TEXT); x.setTextSize(18); x.setPadding(p12, 0, p12, 0);
        x.setOnClickListener(v -> toggleMenu());
        head.addView(x);
        head.setOnTouchListener(new View.OnTouchListener() {
            float dx, dy; int sx, sy;
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (menuLp == null || menu == null) return false;
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN: dx = e.getRawX(); dy = e.getRawY(); sx = menuLp.x; sy = menuLp.y; return true;
                    case MotionEvent.ACTION_MOVE: menuLp.x = sx + (int) (e.getRawX() - dx); menuLp.y = sy + (int) (e.getRawY() - dy); wm.updateViewLayout(menu, menuLp); return true;
                    default: return true;
                }
            }
        });
        root.addView(head);

        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL); list.setPadding(p12, 0, p12, p12);
        for (final Effect e : fx.fx) {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL); card.setPadding(p12, p12, p12, p8);
            card.setBackground(Ui.round(Ui.CARD, Ui.dp(this, 14), 0, 0));
            LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
            TextView tt = new TextView(this); tt.setText(e.title); tt.setTextColor(Ui.TEXT); tt.setTextSize(15); tt.setTypeface(Typeface.DEFAULT_BOLD);
            row.addView(tt, new LinearLayout.LayoutParams(0, -2, 1));
            row.addView(new Ui.Toggle(this, e.on(), v -> Prefs.set(e.key + ".on", v)));
            card.addView(row);
            card.addView(new Ui.Slider(this, "Количество", Prefs.i(e.key + ".dens"), v -> Prefs.set(e.key + ".dens", v)));
            card.addView(new Ui.Slider(this, "Скорость", Prefs.i(e.key + ".speed"), v -> Prefs.set(e.key + ".speed", v)));
            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-1, -2); clp.bottomMargin = p8;
            list.addView(card, clp);
        }
        LinearLayout g = new LinearLayout(this);
        g.setOrientation(LinearLayout.VERTICAL); g.setPadding(p12, p12, p12, p8);
        g.setBackground(Ui.round(Ui.CARD, Ui.dp(this, 14), 0, 0));
        TextView gt = new TextView(this); gt.setText("Общее"); gt.setTextColor(Ui.TEXT); gt.setTextSize(15); gt.setTypeface(Typeface.DEFAULT_BOLD);
        g.addView(gt);
        g.addView(new Ui.Slider(this, "Прозрачность эффектов", Prefs.i("global.alpha"), v -> Prefs.set("global.alpha", v)));
        list.addView(g, new LinearLayout.LayoutParams(-1, -2));
        sv.addView(list);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));
        return root;
    }

    @Override public void onDestroy() {
        Prefs.listener = null;
        for (View v : new View[]{menu, bubble, fx}) if (v != null) { try { wm.removeView(v); } catch (Exception ignored) { } }
        menu = null; bubble = null; fx = null;
        super.onDestroy();
    }
}
