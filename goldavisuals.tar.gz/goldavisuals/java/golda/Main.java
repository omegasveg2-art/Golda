package golda;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class Main extends Activity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(0xFF0D0D14);
        int p = Ui.dp(this, 24); root.setPadding(p, p, p, p);

        TextView t = new TextView(this); t.setText("GoldaVisuals"); t.setTextColor(Ui.GOLD); t.setTextSize(30); t.setTypeface(Typeface.DEFAULT_BOLD); t.setGravity(Gravity.CENTER);
        TextView s = new TextView(this);
        s.setText("Красивые эффекты поверх игры: снег, кометы, северное сияние, звёзды, сакура, светлячки.\n\nНичего не читает из игры и не даёт преимуществ — только визуал.\n\n1) Запусти\n2) Открой игру\n3) Тапни золотую «G» и включи что нравится");
        s.setTextColor(Ui.DIM); s.setTextSize(14); s.setGravity(Gravity.CENTER); s.setPadding(0, p / 2, 0, p);
        Button go = new Button(this); go.setText("ЗАПУСТИТЬ"); go.setTextColor(0xFF1A1405); go.setBackground(Ui.round(Ui.GOLD, Ui.dp(this, 14), 0, 0));
        Button stop = new Button(this); stop.setText("Остановить"); stop.setTextColor(Ui.TEXT); stop.setBackground(Ui.round(Ui.CARD, Ui.dp(this, 14), 0, 0));
        root.addView(t); root.addView(s);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, Ui.dp(this, 52)); lp.bottomMargin = Ui.dp(this, 10);
        root.addView(go, lp); root.addView(stop, new LinearLayout.LayoutParams(-1, Ui.dp(this, 52)));
        setContentView(root);

        go.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Разреши «поверх других окон» и нажми ещё раз", Toast.LENGTH_LONG).show();
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
                return;
            }
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
            startForegroundService(new Intent(this, VisualsService.class));
            Toast.makeText(this, "Запущено — ищи золотую G", Toast.LENGTH_SHORT).show();
        });
        stop.setOnClickListener(v -> stopService(new Intent(this, VisualsService.class)));
    }
}
