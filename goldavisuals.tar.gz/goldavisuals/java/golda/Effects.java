package golda;

import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import java.util.Random;

/** Pure cosmetic particle effects drawn on a transparent overlay. Nothing here reads or touches the game. */
abstract class Effect {
    final String key, title;
    float W, H, D, af = 1f;
    final Random rnd = new Random();
    Effect(String key, String title) { this.key = key; this.title = title; }
    boolean on() { return Prefs.b(key + ".on"); }
    float dens() { return Prefs.i(key + ".dens") / 100f; }
    float speed() { return 0.25f + Prefs.i(key + ".speed") / 100f * 1.75f; }   // 0.25x .. 2x
    void resize(float w, float h, float d) { W = w; H = h; D = d; af = Math.max(0.5f, Math.min(2f, w * h / 2.6e6f)); onResize(); }
    void onResize() { }
    abstract void update(float dt);
    abstract void draw(Canvas c, Paint p, float ga);
    static int col(int rgb, float a) { a = a < 0 ? 0 : (a > 1 ? 1 : a); return ((int) (a * 255) << 24) | (rgb & 0xFFFFFF); }
}

/** snow: layered flakes, bigger = faster + brighter, sideways sway */
class SnowEffect extends Effect {
    float[] x = new float[0], y, r, ph, vy; int n;
    SnowEffect() { super("snow", "Снег"); }
    private void ensure() {
        int t = (int) ((10 + dens() * 260) * af);
        if (t == n) return;
        float[] nx = new float[t], ny = new float[t], nr = new float[t], np = new float[t], nv = new float[t];
        for (int i = 0; i < t; i++) {
            if (i < n) { nx[i] = x[i]; ny[i] = y[i]; nr[i] = r[i]; np[i] = ph[i]; nv[i] = vy[i]; }
            else spawn(nx, ny, nr, np, nv, i, true);
        }
        x = nx; y = ny; r = nr; ph = np; vy = nv; n = t;
    }
    private void spawn(float[] ax, float[] ay, float[] ar, float[] ap, float[] av, int i, boolean anywhere) {
        ax[i] = rnd.nextFloat() * W; ay[i] = anywhere ? rnd.nextFloat() * H : -10 * D;
        ar[i] = (1.2f + rnd.nextFloat() * 3.3f) * D * 0.9f; ap[i] = rnd.nextFloat() * 6.28f;
        av[i] = (26 + ar[i] / D * 15) * D;
    }
    @Override void onResize() { n = -1; x = new float[0]; ensure(); }
    @Override void update(float dt) {
        ensure(); float s = speed();
        for (int i = 0; i < n; i++) {
            y[i] += vy[i] * s * dt; ph[i] += dt * (0.8f + r[i] / D * 0.2f) * s;
            x[i] += (float) Math.sin(ph[i]) * 22 * D * dt * s;
            if (y[i] > H + 10 * D) spawn(x, y, r, ph, vy, i, false);
            if (x[i] < -10 * D) x[i] = W + 5 * D; else if (x[i] > W + 10 * D) x[i] = -5 * D;
        }
    }
    @Override void draw(Canvas c, Paint p, float ga) {
        for (int i = 0; i < n; i++) {
            float k = 0.5f + r[i] / (5.5f * D) * 0.5f;
            p.setColor(col(0xDDEEFF, 0.12f * ga)); c.drawCircle(x[i], y[i], r[i] * 2.3f, p);
            p.setColor(col(0xFFFFFF, 0.92f * k * ga)); c.drawCircle(x[i], y[i], r[i], p);
        }
    }
}

/** sakura petals: slow tumbling pink ovals */
class PetalsEffect extends Effect {
    float[] x = new float[0], y, s, ph, rot, vy; int n;
    final RectF rc = new RectF();
    PetalsEffect() { super("petals", "Лепестки сакуры"); }
    private void spawn(float[] ax, float[] ay, float[] as, float[] ap, float[] ar, float[] av, int i, boolean anywhere) {
        ax[i] = rnd.nextFloat() * W; ay[i] = anywhere ? rnd.nextFloat() * H : -12 * D;
        as[i] = (3.5f + rnd.nextFloat() * 3.5f) * D; ap[i] = rnd.nextFloat() * 6.28f; ar[i] = rnd.nextFloat() * 360f;
        av[i] = (20 + rnd.nextFloat() * 22) * D;
    }
    private void ensure() {
        int t = (int) ((6 + dens() * 70) * af);
        if (t == n) return;
        float[] nx = new float[t], ny = new float[t], ns = new float[t], np = new float[t], nr = new float[t], nv = new float[t];
        for (int i = 0; i < t; i++) {
            if (i < n) { nx[i] = x[i]; ny[i] = y[i]; ns[i] = s[i]; np[i] = ph[i]; nr[i] = rot[i]; nv[i] = vy[i]; }
            else spawn(nx, ny, ns, np, nr, nv, i, true);
        }
        x = nx; y = ny; s = ns; ph = np; rot = nr; vy = nv; n = t;
    }
    @Override void onResize() { n = -1; x = new float[0]; ensure(); }
    @Override void update(float dt) {
        ensure(); float sp = speed();
        for (int i = 0; i < n; i++) {
            y[i] += vy[i] * sp * dt; ph[i] += dt * 1.3f * sp; rot[i] += 70f * dt * sp;
            x[i] += ((float) Math.sin(ph[i]) * 38 + 14) * D * dt * sp;
            if (y[i] > H + 14 * D || x[i] > W + 14 * D) spawn(x, y, s, ph, rot, vy, i, false);
        }
    }
    @Override void draw(Canvas c, Paint p, float ga) {
        for (int i = 0; i < n; i++) {
            c.save(); c.translate(x[i], y[i]); c.rotate(rot[i]);
            float sq = 0.55f + 0.45f * (float) Math.abs(Math.cos(ph[i]));   // fake 3D flutter
            rc.set(-s[i], -s[i] * 0.55f * sq, s[i], s[i] * 0.55f * sq);
            p.setColor(col(0xFFB7D5, 0.85f * ga)); c.drawOval(rc, p);
            rc.set(-s[i] * 0.5f, -s[i] * 0.3f * sq, s[i] * 0.9f, s[i] * 0.2f * sq);
            p.setColor(col(0xFFE3EE, 0.55f * ga)); c.drawOval(rc, p);
            c.restore();
        }
    }
}

/** comets: periodic bright heads with long fading tails, diagonal top-right -> bottom-left */
class CometEffect extends Effect {
    static final int MAX = 7, TAIL = 24;
    static final int[] COLS = {0xFFD97A, 0x9FD8FF, 0xFFFFFF, 0xFFA8E0, 0x9DFFD0};
    final float[] cx = new float[MAX], cy = new float[MAX], vx = new float[MAX], vy = new float[MAX], ln = new float[MAX], hr = new float[MAX];
    final int[] cc = new int[MAX]; final boolean[] alive = new boolean[MAX];
    float timer = 0.5f;
    CometEffect() { super("comets", "Кометы"); }
    @Override void update(float dt) {
        float s = speed();
        timer -= dt * s;
        if (timer <= 0) {
            timer = (3.2f - dens() * 2.9f) * (0.6f + rnd.nextFloat() * 0.8f);
            for (int i = 0; i < MAX; i++) if (!alive[i]) {
                alive[i] = true;
                double a = Math.toRadians(22 + rnd.nextFloat() * 22);
                float sp = (520 + rnd.nextFloat() * 380) * D;
                vx[i] = (float) -Math.cos(a) * sp; vy[i] = (float) Math.sin(a) * sp;
                cx[i] = W * (0.35f + rnd.nextFloat() * 0.8f); cy[i] = -20 * D - rnd.nextFloat() * H * 0.25f;
                ln[i] = (130 + rnd.nextFloat() * 150) * D; hr[i] = (2.6f + rnd.nextFloat() * 2f) * D;
                cc[i] = COLS[rnd.nextInt(COLS.length)];
                break;
            }
        }
        for (int i = 0; i < MAX; i++) if (alive[i]) {
            cx[i] += vx[i] * dt * (0.5f + s * 0.5f); cy[i] += vy[i] * dt * (0.5f + s * 0.5f);
            if (cx[i] < -ln[i] || cy[i] > H + ln[i]) alive[i] = false;
        }
    }
    @Override void draw(Canvas c, Paint p, float ga) {
        for (int i = 0; i < MAX; i++) if (alive[i]) {
            float m = (float) Math.sqrt(vx[i] * vx[i] + vy[i] * vy[i]), ux = -vx[i] / m, uy = -vy[i] / m;
            for (int k = TAIL; k >= 1; k--) {
                float t = k / (float) TAIL, d = t * ln[i];
                p.setColor(col(cc[i], (1 - t) * (1 - t) * 0.75f * ga));
                c.drawCircle(cx[i] + ux * d, cy[i] + uy * d, hr[i] * (1 - t * 0.8f), p);
            }
            p.setColor(col(cc[i], 0.18f * ga)); c.drawCircle(cx[i], cy[i], hr[i] * 4.2f, p);
            p.setColor(col(cc[i], 0.35f * ga)); c.drawCircle(cx[i], cy[i], hr[i] * 2.2f, p);
            p.setColor(col(0xFFFFFF, 0.95f * ga)); c.drawCircle(cx[i], cy[i], hr[i], p);
        }
    }
}

/** twinkling stars */
class StarsEffect extends Effect {
    float[] x = new float[0], y, r, ph, ts; int n;
    StarsEffect() { super("stars", "Звёзды"); }
    private void ensure() {
        int t = (int) ((30 + dens() * 170) * af);
        if (t == n) return;
        float[] nx = new float[t], ny = new float[t], nr = new float[t], np = new float[t], nt = new float[t];
        for (int i = 0; i < t; i++) {
            if (i < n) { nx[i] = x[i]; ny[i] = y[i]; nr[i] = r[i]; np[i] = ph[i]; nt[i] = ts[i]; }
            else { nx[i] = rnd.nextFloat() * W; ny[i] = rnd.nextFloat() * H * 0.8f; nr[i] = (0.7f + rnd.nextFloat() * 1.9f) * D; np[i] = rnd.nextFloat() * 6.28f; nt[i] = 0.6f + rnd.nextFloat() * 2f; }
        }
        x = nx; y = ny; r = nr; ph = np; ts = nt; n = t;
    }
    @Override void onResize() { n = -1; x = new float[0]; ensure(); }
    @Override void update(float dt) { ensure(); float s = speed(); for (int i = 0; i < n; i++) ph[i] += dt * ts[i] * s * 2f; }
    @Override void draw(Canvas c, Paint p, float ga) {
        for (int i = 0; i < n; i++) {
            float a = 0.3f + 0.7f * (0.5f + 0.5f * (float) Math.sin(ph[i]));
            p.setColor(col(0xBFD8FF, 0.14f * a * ga)); c.drawCircle(x[i], y[i], r[i] * 3.2f, p);
            p.setColor(col(0xFFFFFF, 0.9f * a * ga)); c.drawCircle(x[i], y[i], r[i], p);
        }
    }
}

/** aurora: 3 soft vertical-gradient curtains whose vertical offset follows a moving sine (shader matrix per strip, no per-frame allocation) */
class AuroraEffect extends Effect {
    static final int[] COLS = {0x3CFFA0, 0x40C8FF, 0xB070FF};
    final Shader[] sh = new Shader[3]; final Matrix mx = new Matrix(); float t;
    float hb;
    AuroraEffect() { super("aurora", "Северное сияние"); }
    @Override void onResize() {
        hb = H * 0.42f;
        for (int i = 0; i < 3; i++) {
            int c = COLS[i];
            sh[i] = new LinearGradient(0, 0, 0, hb, new int[]{c & 0xFFFFFF, (0xB0 << 24) | c, c & 0xFFFFFF}, new float[]{0f, 0.35f, 1f}, Shader.TileMode.CLAMP);
        }
    }
    @Override void update(float dt) { t += dt * speed() * 0.6f; }
    @Override void draw(Canvas c, Paint p, float ga) {
        if (sh[0] == null) return;
        final int N = 54; float w = W / N;
        for (int b = 0; b < 3; b++) {
            p.setShader(sh[b]);
            float inten = (0.35f + dens() * 0.65f);
            for (int i = 0; i < N; i++) {
                float x0 = i * w;
                float wave = (float) (Math.sin(x0 / W * 5.2 + t * (1.0 + b * 0.35) + b * 1.7) * 0.07 + Math.sin(x0 / W * 11.0 - t * 0.8 + b) * 0.025) * H;
                float yo = H * (0.02f + b * 0.07f) + wave;
                float vi = 0.55f + 0.45f * (float) Math.sin(x0 / W * 7.0 + t * 1.3 + b * 2.1);
                mx.setTranslate(0, yo); sh[b].setLocalMatrix(mx);
                p.setAlpha((int) (255 * Math.max(0, Math.min(1, inten * vi * ga))));
                c.drawRect(x0, yo, x0 + w + 1, yo + hb, p);
            }
        }
        p.setShader(null);
    }
}

/** fireflies: warm glowing dots drifting on a random walk, pulsing */
class FirefliesEffect extends Effect {
    float[] x = new float[0], y, a, ph; int n;
    FirefliesEffect() { super("flies", "Светлячки"); }
    private void ensure() {
        int t = (int) ((8 + dens() * 50) * af);
        if (t == n) return;
        float[] nx = new float[t], ny = new float[t], na = new float[t], np = new float[t];
        for (int i = 0; i < t; i++) {
            if (i < n) { nx[i] = x[i]; ny[i] = y[i]; na[i] = a[i]; np[i] = ph[i]; }
            else { nx[i] = rnd.nextFloat() * W; ny[i] = rnd.nextFloat() * H; na[i] = rnd.nextFloat() * 6.28f; np[i] = rnd.nextFloat() * 6.28f; }
        }
        x = nx; y = ny; a = na; ph = np; n = t;
    }
    @Override void onResize() { n = -1; x = new float[0]; ensure(); }
    @Override void update(float dt) {
        ensure(); float s = speed();
        for (int i = 0; i < n; i++) {
            a[i] += (rnd.nextFloat() - 0.5f) * dt * 5f; ph[i] += dt * 2.2f * s;
            x[i] += (float) Math.cos(a[i]) * 26 * D * dt * s; y[i] += (float) Math.sin(a[i]) * 26 * D * dt * s;
            if (x[i] < -10) x[i] = W + 5; else if (x[i] > W + 10) x[i] = -5;
            if (y[i] < -10) y[i] = H + 5; else if (y[i] > H + 10) y[i] = -5;
        }
    }
    @Override void draw(Canvas c, Paint p, float ga) {
        for (int i = 0; i < n; i++) {
            float k = 0.25f + 0.75f * (0.5f + 0.5f * (float) Math.sin(ph[i]));
            p.setColor(col(0xFFE680, 0.10f * k * ga)); c.drawCircle(x[i], y[i], 9 * D, p);
            p.setColor(col(0xFFE680, 0.25f * k * ga)); c.drawCircle(x[i], y[i], 4.5f * D, p);
            p.setColor(col(0xFFF6C8, 0.95f * k * ga)); c.drawCircle(x[i], y[i], 1.6f * D, p);
        }
    }
}
