package golda;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.HashMap;

/** Tiny int-only settings store with an in-memory cache (read every frame by the effects, so no disk hits). Main thread only. */
final class Prefs {
    private static SharedPreferences sp;
    private static final HashMap<String, Integer> cache = new HashMap<>();
    static Runnable listener;

    static void init(Context c) { if (sp == null) sp = c.getApplicationContext().getSharedPreferences("golda", 0); }

    private static int def(String k) {
        if (k.equals("global.alpha")) return 85;
        if (k.endsWith(".on")) return 0;
        return 50;   // .dens / .speed
    }
    static int i(String k) {
        Integer v = cache.get(k);
        if (v != null) return v;
        int d = def(k);
        try { if (sp != null) d = sp.getInt(k, d); } catch (Exception ignored) { }
        cache.put(k, d);
        return d;
    }
    static boolean b(String k) { return i(k) != 0; }
    static void set(String k, int v) {
        cache.put(k, v);
        try { if (sp != null) sp.edit().putInt(k, v).apply(); } catch (Exception ignored) { }
        if (listener != null) listener.run();
    }
}
