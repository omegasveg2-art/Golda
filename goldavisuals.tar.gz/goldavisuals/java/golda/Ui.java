package golda;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.view.MotionEvent;
import android.view.View;

final class Ui {
    static final int GOLD = 0xFFE6B450, GOLD_D = 0xFF9A7A2E, BG = 0xF2101018, CARD = 0xFF1B1B26, TRACK = 0xFF34343F, TEXT = 0xFFEDEDF2, DIM = 0xFF8A8A99;

    static int dp(Context c, float v) { return (int) (v * c.getResources().getDisplayMetrics().density + 0.5f); }

    static GradientDrawable round(int color, float radiusPx, int strokeColor, int strokePx) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color); g.setCornerRadius(radiusPx);
        if (strokePx > 0) g.setStroke(strokePx, strokeColor);
        return g;
    }

    interface IntCb { void on(int v); }

    /** pill switch with a sliding knob */
    static class Toggle extends View {
        boolean on; float anim; final IntCb cb; final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG); final RectF rc = new RectF();
        Toggle(Context c, boolean init, IntCb cb) {
            super(c); on = init; anim = init ? 1 : 0; this.cb = cb;
            setOnClickListener(v -> { on = !on; cb.on(on ? 1 : 0); invalidate(); });
        }
        @Override protected void onMeasure(int w, int h) { setMeasuredDimension(dp(getContext(), 46), dp(getContext(), 26)); }
        @Override protected void onDraw(Canvas c) {
            float tgt = on ? 1 : 0;
            if (Math.abs(anim - tgt) > 0.02f) { anim += (tgt - anim) * 0.3f; postInvalidateOnAnimation(); } else anim = tgt;
            float w = getWidth(), h = getHeight();
            p.setColor(blend(TRACK, GOLD_D, anim)); rc.set(0, 0, w, h); c.drawRoundRect(rc, h / 2, h / 2, p);
            float r = h / 2 - dp(getContext(), 3), cx = h / 2 + (w - h) * anim;
            p.setColor(blend(0xFFB0B0BC, 0xFFFFE9A8, anim)); c.drawCircle(cx, h / 2, r, p);
        }
    }

    /** gold slider 0..100 with value label on the right */
    static class Slider extends View {
        int val; final String label; final IntCb cb; final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG); final RectF rc = new RectF();
        Slider(Context c, String label, int init, IntCb cb) { super(c); this.label = label; val = init; this.cb = cb; }
        @Override protected void onMeasure(int w, int h) { setMeasuredDimension(MeasureSpec.getSize(w), dp(getContext(), 40)); }
        @Override protected void onDraw(Canvas c) {
            Context cx = getContext(); float w = getWidth(), d = cx.getResources().getDisplayMetrics().density;
            p.setTextSize(12 * d); p.setColor(DIM); c.drawText(label, 0, 13 * d, p);
            p.setTextAlign(Paint.Align.RIGHT); p.setColor(TEXT); c.drawText(String.valueOf(val), w, 13 * d, p); p.setTextAlign(Paint.Align.LEFT);
            float y = 28 * d, th = 4 * d, x0 = 6 * d, x1 = w - 6 * d, kx = x0 + (x1 - x0) * val / 100f;
            p.setColor(TRACK); rc.set(x0, y - th / 2, x1, y + th / 2); c.drawRoundRect(rc, th, th, p);
            p.setColor(GOLD); rc.set(x0, y - th / 2, kx, y + th / 2); c.drawRoundRect(rc, th, th, p);
            p.setColor(0x33E6B450); c.drawCircle(kx, y, 10 * d, p);
            p.setColor(0xFFFFE9A8); c.drawCircle(kx, y, 6.5f * d, p);
        }
        @Override public boolean onTouchEvent(MotionEvent e) {
            if (e.getActionMasked() == MotionEvent.ACTION_DOWN && getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
            float d = getResources().getDisplayMetrics().density, x0 = 6 * d, x1 = getWidth() - 6 * d;
            int nv = (int) Math.round(Math.max(0, Math.min(1, (e.getX() - x0) / (x1 - x0))) * 100);
            if (nv != val) { val = nv; cb.on(nv); invalidate(); }
            return true;
        }
    }

    static int blend(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t), g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t), bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }
}
